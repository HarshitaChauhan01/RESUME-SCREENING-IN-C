<?php
// api.php
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'login':
        // Get POST data
        $data = json_decode(file_get_contents('php://input'), true);
        $username = escapeshellarg($data['username'] ?? '');
        $password = escapeshellarg($data['password'] ?? '');
        
        // Call your C program with arguments
        $output = shell_exec("./resume_screener login $username $password");
        echo $output;
        break;
        
    case 'register':
        $data = json_decode(file_get_contents('php://input'), true);
        $username = escapeshellarg($data['username'] ?? '');
        $password = escapeshellarg($data['password'] ?? '');
        $role = $data['role'] == 'recruiter' ? 1 : 0;
        
        $output = shell_exec("./resume_screener register $username $password $role");
        echo $output;
        break;
        
    // Add more cases for other actions
    
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
?>