#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

#define MAX_STRING 256
#define MAX_SKILLS 20
#define MAX_USERS 100
#define MAX_RESUMES 100
#define HASH_TABLE_SIZE 100
#define MAX_PASSWORD 64
#define MAX_USERNAME 64

// ====== DATA STRUCTURES ======

// User structure for authentication
typedef enum
{
    CANDIDATE,
    RECRUITER
} UserRole;

typedef struct
{
    char username[MAX_USERNAME];
    char password[MAX_PASSWORD];
    UserRole role;
} User;

// Skill structure
typedef struct
{
    char name[MAX_STRING];
    int proficiency; // 1-10 rating
} Skill;

// Resume structure
typedef struct Resume
{
    int id;
    char name[MAX_STRING];
    int years_experience;
    Skill skills[MAX_SKILLS];
    int skill_count;
    float match_score;   // Used for ranking
    struct Resume *next; // For linked list implementation
} Resume;

// Linked List for storing resumes
typedef struct
{
    Resume *head;
    int count;
} LinkedList;

// Trie Node for efficient skill searching
typedef struct TrieNode
{
    struct TrieNode *children[26]; // Lowercase English letters
    bool is_end_of_word;
    Resume *resumes[MAX_RESUMES]; // Resumes containing this skill
    int resume_count;
} TrieNode;

// Hash Table for quick resume retrieval
typedef struct
{
    Resume *buckets[HASH_TABLE_SIZE];
} HashTable;

// Priority Queue Node for ranking candidates
typedef struct PQNode
{
    Resume *resume;
    struct PQNode *next;
} PQNode;

typedef struct
{
    PQNode *head;
    int size;
} PriorityQueue;

// Global data
User users[MAX_USERS];
int user_count = 0;
LinkedList resume_list;
HashTable resume_table;
TrieNode *skill_trie;
int current_user_index = -1;

// ====== LINKED LIST FUNCTIONS ======

void init_linked_list(LinkedList *list)
{
    list->head = NULL;
    list->count = 0;
}

void add_resume(LinkedList *list, Resume *resume)
{
    resume->next = list->head;
    list->head = resume;
    list->count++;
}

Resume *find_resume_by_id(LinkedList *list, int id)
{
    Resume *current = list->head;
    while (current != NULL)
    {
        if (current->id == id)
        {
            return current;
        }
        current = current->next;
    }
    return NULL;
}

// ====== TRIE FUNCTIONS ======

TrieNode *create_trie_node()
{
    TrieNode *node = (TrieNode *)malloc(sizeof(TrieNode));
    if (node)
    {
        for (int i = 0; i < 26; i++)
        {
            node->children[i] = NULL;
        }
        node->is_end_of_word = false;
        node->resume_count = 0;
    }
    return node;
}

void insert_skill(TrieNode *root, const char *skill, Resume *resume)
{
    TrieNode *current = root;

    for (int i = 0; skill[i] != '\0'; i++)
    {
        int index = tolower(skill[i]) - 'a';
        if (index < 0 || index >= 26)
            continue; // Skip non-alphabet chars

        if (!current->children[index])
        {
            current->children[index] = create_trie_node();
        }
        current = current->children[index];
    }

    current->is_end_of_word = true;
    // Add resume to this skill node if not already present
    bool already_added = false;
    for (int i = 0; i < current->resume_count; i++)
    {
        if (current->resumes[i]->id == resume->id)
        {
            already_added = true;
            break;
        }
    }

    if (!already_added && current->resume_count < MAX_RESUMES)
    {
        current->resumes[current->resume_count++] = resume;
    }
}

void search_resumes_by_skill(TrieNode *root, const char *skill, Resume **results, int *count)
{
    *count = 0;
    TrieNode *current = root;

    for (int i = 0; skill[i] != '\0'; i++)
    {
        int index = tolower(skill[i]) - 'a';
        if (index < 0 || index >= 26 || !current->children[index])
        {
            return; // Skill not found
        }
        current = current->children[index];
    }

    if (current->is_end_of_word)
    {
        for (int i = 0; i < current->resume_count; i++)
        {
            results[(*count)++] = current->resumes[i];
        }
    }
}

// ====== HASH TABLE FUNCTIONS ======

unsigned int hash(int id)
{
    return id % HASH_TABLE_SIZE;
}

void init_hash_table(HashTable *table)
{
    for (int i = 0; i < HASH_TABLE_SIZE; i++)
    {
        table->buckets[i] = NULL;
    }
}

void insert_resume_to_hash(HashTable *table, Resume *resume)
{
    unsigned int index = hash(resume->id);
    resume->next = table->buckets[index];
    table->buckets[index] = resume;
}

Resume *find_resume_by_id_hash(HashTable *table, int id)
{
    unsigned int index = hash(id);
    Resume *current = table->buckets[index];

    while (current != NULL)
    {
        if (current->id == id)
        {
            return current;
        }
        current = current->next;
    }

    return NULL;
}

// ====== PRIORITY QUEUE FUNCTIONS ======

void init_priority_queue(PriorityQueue *pq)
{
    pq->head = NULL;
    pq->size = 0;
}

void enqueue(PriorityQueue *pq, Resume *resume)
{
    PQNode *new_node = (PQNode *)malloc(sizeof(PQNode));
    new_node->resume = resume;

    // Insert based on match_score (higher score first)
    if (pq->head == NULL || resume->match_score > pq->head->resume->match_score)
    {
        new_node->next = pq->head;
        pq->head = new_node;
    }
    else
    {
        PQNode *current = pq->head;
        while (current->next != NULL &&
               current->next->resume->match_score >= resume->match_score)
        {
            current = current->next;
        }
        new_node->next = current->next;
        current->next = new_node;
    }

    pq->size++;
}

Resume *dequeue(PriorityQueue *pq)
{
    if (pq->head == NULL)
    {
        return NULL;
    }

    PQNode *temp = pq->head;
    Resume *resume = temp->resume;
    pq->head = pq->head->next;
    free(temp);
    pq->size--;

    return resume;
}

// ====== FILE HANDLING FUNCTIONS ======

void save_users()
{
    FILE *file = fopen("users.dat", "wb");
    if (file == NULL)
    {
        printf("Error opening users file for writing.\n");
        return;
    }

    fwrite(&user_count, sizeof(int), 1, file);
    fwrite(users, sizeof(User), user_count, file);

    fclose(file);
}

void load_users()
{
    FILE *file = fopen("users.dat", "rb");
    if (file == NULL)
    {
        printf("No users file found. Starting with empty user database.\n");
        return;
    }

    fread(&user_count, sizeof(int), 1, file);
    fread(users, sizeof(User), user_count, file);

    fclose(file);
}

void save_resumes()
{
    FILE *file = fopen("resumes.dat", "wb");
    if (file == NULL)
    {
        printf("Error opening resumes file for writing.\n");
        return;
    }

    // Save the number of resumes
    fwrite(&resume_list.count, sizeof(int), 1, file);

    // Save each resume
    Resume *current = resume_list.head;
    while (current != NULL)
    {
        fwrite(current, sizeof(Resume), 1, file);
        current = current->next;
    }

    fclose(file);
}

void load_resumes()
{
    FILE *file = fopen("resumes.dat", "rb");
    if (file == NULL)
    {
        printf("No resumes file found. Starting with empty resume database.\n");
        return;
    }

    int resume_count;
    fread(&resume_count, sizeof(int), 1, file);

    for (int i = 0; i < resume_count; i++)
    {
        Resume *resume = (Resume *)malloc(sizeof(Resume));
        fread(resume, sizeof(Resume), 1, file);
        resume->next = NULL;

        // Add to linked list
        add_resume(&resume_list, resume);

        // Add to hash table
        insert_resume_to_hash(&resume_table, resume);

        // Add skills to trie
        for (int j = 0; j < resume->skill_count; j++)
        {
            insert_skill(skill_trie, resume->skills[j].name, resume);
        }
    }

    fclose(file);
}

// ====== AUTHENTICATION FUNCTIONS ======

void sign_up()
{
    User new_user;

    printf("\n===== SIGN UP =====\n");
    printf("Enter username: ");
    scanf("%s", new_user.username);

    // Check if username already exists
    for (int i = 0; i < user_count; i++)
    {
        if (strcmp(users[i].username, new_user.username) == 0)
        {
            printf("Username already exists. Please try another.\n");
            return;
        }
    }

    printf("Enter password: ");
    scanf("%s", new_user.password);

    int role;
    printf("Select role (0 for Candidate, 1 for Recruiter): ");
    scanf("%d", &role);
    new_user.role = (role == 1) ? RECRUITER : CANDIDATE;

    users[user_count++] = new_user;
    save_users();

    printf("Sign up successful! You can now log in.\n");
}

bool login()
{
    char username[MAX_USERNAME];
    char password[MAX_PASSWORD];

    printf("\n===== LOGIN =====\n");
    printf("Enter username: ");
    scanf("%s", username);
    printf("Enter password: ");
    scanf("%s", password);

    for (int i = 0; i < user_count; i++)
    {
        if (strcmp(users[i].username, username) == 0 &&
            strcmp(users[i].password, password) == 0)
        {
            current_user_index = i;
            printf("Login successful! Welcome, %s.\n", username);
            return true;
        }
    }

    printf("Invalid username or password. Please try again.\n");
    return false;
}

// ====== RESUME MANAGEMENT FUNCTIONS ======

void add_new_resume()
{
    if (current_user_index == -1 || users[current_user_index].role != CANDIDATE)
    {
        printf("You must be logged in as a candidate to add a resume.\n");
        return;
    }

    Resume *new_resume = (Resume *)malloc(sizeof(Resume));
    new_resume->id = resume_list.count + 1;
    strcpy(new_resume->name, users[current_user_index].username);

    printf("\n===== ADD RESUME =====\n");
    printf("Enter years of experience: ");
    scanf("%d", &new_resume->years_experience);

    printf("Enter number of skills (max %d): ", MAX_SKILLS);
    scanf("%d", &new_resume->skill_count);

    if (new_resume->skill_count > MAX_SKILLS)
    {
        new_resume->skill_count = MAX_SKILLS;
    }

    printf("Enter skills and proficiency (1-10) for each:\n");
    for (int i = 0; i < new_resume->skill_count; i++)
    {
        printf("Skill %d name: ", i + 1);
        scanf("%s", new_resume->skills[i].name);

        printf("Proficiency (1-10): ");
        scanf("%d", &new_resume->skills[i].proficiency);

        if (new_resume->skills[i].proficiency < 1)
        {
            new_resume->skills[i].proficiency = 1;
        }
        else if (new_resume->skills[i].proficiency > 10)
        {
            new_resume->skills[i].proficiency = 10;
        }

        // Add to trie for skill searching
        insert_skill(skill_trie, new_resume->skills[i].name, new_resume);
    }

    // Add to linked list
    add_resume(&resume_list, new_resume);

    // Add to hash table
    insert_resume_to_hash(&resume_table, new_resume);

    // Save to file
    save_resumes();

    printf("Resume added successfully with ID: %d\n", new_resume->id);
}

// Calculate match score between required skills and a resume
float calculate_match_score(const char *required_skills[], int skill_count, Resume *resume)
{
    int matched = 0;
    int total_proficiency = 0;

    for (int i = 0; i < skill_count; i++)
    {
        for (int j = 0; j < resume->skill_count; j++)
        {
            if (strcasecmp(required_skills[i], resume->skills[j].name) == 0)
            {
                matched++;
                total_proficiency += resume->skills[j].proficiency;
                break;
            }
        }
    }

    // Calculate score based on match percentage and average proficiency
    float match_percentage = (float)matched / skill_count;
    float avg_proficiency = (matched > 0) ? (float)total_proficiency / matched / 10.0 : 0;

    // Weight match percentage higher than proficiency
    return (match_percentage * 0.7 + avg_proficiency * 0.3) * 100.0;
}

void search_candidates()
{
    if (current_user_index == -1 || users[current_user_index].role != RECRUITER)
    {
        printf("You must be logged in as a recruiter to search for candidates.\n");
        return;
    }

    printf("\n===== SEARCH CANDIDATES =====\n");

    // Get required skills
    int skill_count;
    printf("Enter number of required skills: ");
    scanf("%d", &skill_count);

    char *required_skills[MAX_SKILLS];
    printf("Enter the required skills:\n");
    for (int i = 0; i < skill_count; i++)
    {
        required_skills[i] = (char *)malloc(MAX_STRING);
        printf("Skill %d: ", i + 1);
        scanf("%s", required_skills[i]);
    }

    // Create a priority queue for ranking
    PriorityQueue pq;
    init_priority_queue(&pq);

    // Search for each skill
    Resume *all_candidate_resumes[MAX_RESUMES * MAX_SKILLS]; // May contain duplicates
    int all_count = 0;

    for (int i = 0; i < skill_count; i++)
    {
        Resume *skill_matches[MAX_RESUMES];
        int match_count = 0;

        search_resumes_by_skill(skill_trie, required_skills[i], skill_matches, &match_count);

        // Add matches to all_candidate_resumes array
        for (int j = 0; j < match_count; j++)
        {
            all_candidate_resumes[all_count++] = skill_matches[j];
        }
    }

    // Remove duplicates and calculate match scores
    bool processed[MAX_RESUMES] = {false};
    for (int i = 0; i < all_count; i++)
    {
        Resume *current = all_candidate_resumes[i];

        if (!processed[current->id - 1])
        {
            processed[current->id - 1] = true;

            // Calculate match score
            current->match_score = calculate_match_score(
                (const char **)required_skills, skill_count, current);

            // Add to priority queue
            enqueue(&pq, current);
        }
    }

    // Display results
    printf("\n===== SEARCH RESULTS =====\n");
    printf("%-10s %-20s %-15s %-10s\n", "ID", "Name", "Years Exp", "Match Score");
    printf("----------------------------------------------------------\n");

    int count = 0;
    while (pq.size > 0 && count < 10)
    { // Show top 10 results
        Resume *match = dequeue(&pq);
        printf("%-10d %-20s %-15d %.2f%%\n",
               match->id, match->name, match->years_experience, match->match_score);
        count++;
    }

    if (count == 0)
    {
        printf("No matching candidates found.\n");
    }

    // Free allocated memory
    for (int i = 0; i < skill_count; i++)
    {
        free(required_skills[i]);
    }
}

// ====== MAIN FUNCTION ======

int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        printf("{\"success\": false, \"message\": \"No action specified\"}");
        return 1;
    }

    // First argument is the action
    char *action = argv[1];

    if (strcmp(action, "login") == 0)
    {
        if (argc < 4)
        {
            printf("{\"success\": false, \"message\": \"Missing username or password\"}");
            return 1;
        }

        char *username = argv[2];
        char *password = argv[3];

        // Call your login function
        // int login_result = login(username, password);
        // For demo:
        int login_result = (strcmp(username, "admin") == 0 && strcmp(password, "password") == 0);

        if (login_result)
        {
            printf("{\"success\": true, \"role\": \"recruiter\"}");
        }
        else
        {
            printf("{\"success\": false, \"message\": \"Invalid credentials\"}");
        }
    }
    // Add more actions

    return 0;
}