// Store user data (in a real app, this would come from the backend)
let currentUser = null
let users = []
let resumes = []

// Initialize the app
document.addEventListener("DOMContentLoaded", function () {
	// Load data from localStorage (simulating database)
	loadData()

	// Set up event listeners
	document.getElementById("login-form").addEventListener("submit", handleLogin)
	document
		.getElementById("signup-form")
		.addEventListener("submit", handleSignup)
	document
		.getElementById("resume-form")
		.addEventListener("submit", handleResumeSubmit)
	document
		.getElementById("search-form")
		.addEventListener("submit", handleSearch)
})

// Load data from localStorage
function loadData() {
	const savedUsers = localStorage.getItem("resumeScreenerUsers")
	const savedResumes = localStorage.getItem("resumeScreenerResumes")

	if (savedUsers) {
		users = JSON.parse(savedUsers)
	}

	if (savedResumes) {
		resumes = JSON.parse(savedResumes)
	}

	// Check if user is logged in
	const savedUser = localStorage.getItem("currentUser")
	if (savedUser) {
		currentUser = JSON.parse(savedUser)
		showUserDashboard()
	}
}

// Save data to localStorage
function saveData() {
	localStorage.setItem("resumeScreenerUsers", JSON.stringify(users))
	localStorage.setItem("resumeScreenerResumes", JSON.stringify(resumes))

	if (currentUser) {
		localStorage.setItem("currentUser", JSON.stringify(currentUser))
	} else {
		localStorage.removeItem("currentUser")
	}
}

// Show notification
function showNotification(message, isError = false) {
	const notification = document.getElementById("notification")
	notification.textContent = message
	notification.classList.remove("hidden")

	if (isError) {
		notification.classList.add("error")
	} else {
		notification.classList.remove("error")
	}

	setTimeout(() => {
		notification.classList.add("hidden")
	}, 3000)
}

// Authentication functions
async function login(username, password) {
	const response = await fetch("api.php?action=login", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
		},
		body: JSON.stringify({ username, password }),
	})

	return await response.json()
}

function handleLogin(e) {
	e.preventDefault()

	const username = document.getElementById("login-username").value
	const password = document.getElementById("login-password").value

	const user = users.find(
		(u) => u.username === username && u.password === password
	)

	if (user) {
		currentUser = user
		saveData()
		showUserDashboard()
		showNotification(`Welcome back, ${username}!`)
	} else {
		showNotification("Invalid username or password", true)
	}
}

function handleSignup(e) {
	e.preventDefault()

	const username = document.getElementById("signup-username").value
	const password = document.getElementById("signup-password").value
	const role = document.querySelector('input[name="role"]:checked').value

	// Check if username exists
	if (users.some((u) => u.username === username)) {
		showNotification("Username already exists", true)
		return
	}

	// Create new user
	const newUser = {
		username,
		password,
		role,
	}

	users.push(newUser)
	saveData()

	showNotification("Account created successfully! You can now log in.")
	showTab("login")
}

function logout() {
	currentUser = null
	saveData()

	document.getElementById("auth-section").classList.remove("hidden")
	document.getElementById("candidate-section").classList.add("hidden")
	document.getElementById("recruiter-section").classList.add("hidden")

	showNotification("Logged out successfully")
}

// Show the appropriate dashboard based on user role
function showUserDashboard() {
	document.getElementById("auth-section").classList.add("hidden")

	if (currentUser.role === "candidate") {
		document.getElementById("candidate-section").classList.remove("hidden")
		document.getElementById("recruiter-section").classList.add("hidden")
		loadCandidateResume()
	} else {
		document.getElementById("recruiter-section").classList.remove("hidden")
		document.getElementById("candidate-section").classList.add("hidden")
		loadAllResumes()
	}
}

// Tab functions
function showTab(tabId) {
	// Hide all tab contents
	const tabContents = document.querySelectorAll(".tab-content")
	tabContents.forEach((tab) => tab.classList.remove("active"))

	// Show the selected tab
	document.getElementById(tabId).classList.add("active")

	// Update tab button active state
	const tabButtons = document.querySelectorAll(".tab-btn")
	tabButtons.forEach((button) => {
		if (button.getAttribute("onclick").includes(tabId)) {
			button.classList.add("active")
		} else {
			button.classList.remove("active")
		}
	})
}

function showCandidateTab(tabId) {
	const tabs = document.querySelectorAll(".candidate-tab")
	tabs.forEach((tab) => tab.classList.remove("active"))
	document.getElementById(tabId).classList.add("active")

	if (tabId === "view-resume") {
		loadCandidateResume()
	}
}

function showRecruiterTab(tabId) {
	const tabs = document.querySelectorAll(".recruiter-tab")
	tabs.forEach((tab) => tab.classList.remove("active"))
	document.getElementById(tabId).classList.add("active")

	if (tabId === "all-resumes") {
		loadAllResumes()
	}
}

// Skill management functions
function addSkill() {
	const container = document.getElementById("skills-container")
	const skillEntry = document.createElement("div")
	skillEntry.className = "skill-entry"
	skillEntry.innerHTML = `
        <input type="text" class="skill-name" placeholder="Skill name" required>
        <select class="skill-proficiency">
            <option value="1">1 - Beginner</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5" selected>5 - Intermediate</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10 - Expert</option>
        </select>
        <button type="button" class="btn remove-skill" onclick="removeSkill(this)">×</button>
    `
	container.appendChild(skillEntry)
}

function removeSkill(button) {
	const skillEntry = button.parentElement
	skillEntry.remove()
}

function addRequiredSkill() {
	const container = document.getElementById("required-skills-container")
	const skillEntry = document.createElement("div")
	skillEntry.className = "required-skill-entry"
	skillEntry.innerHTML = `
        <input type="text" class="required-skill" placeholder="Enter a skill" required>
        <button type="button" class="btn remove-skill" onclick="removeRequiredSkill(this)">×</button>
    `
	container.appendChild(skillEntry)
}

function removeRequiredSkill(button) {
	const skillEntry = button.parentElement
	skillEntry.remove()
}

// Resume management functions
function handleResumeSubmit(e) {
	e.preventDefault()

	const yearsExperience = parseInt(
		document.getElementById("years-experience").value
	)
	const skillEntries = document.querySelectorAll(".skill-entry")

	const skills = []
	skillEntries.forEach((entry) => {
		const skillName = entry.querySelector(".skill-name").value
		const proficiency = parseInt(
			entry.querySelector(".skill-proficiency").value
		)

		if (skillName.trim() !== "") {
			skills.push({
				name: skillName,
				proficiency: proficiency,
			})
		}
	})

	// Check if user already has a resume
	const existingResumeIndex = resumes.findIndex(
		(r) => r.username === currentUser.username
	)

	const resumeData = {
		id:
			existingResumeIndex >= 0
				? resumes[existingResumeIndex].id
				: resumes.length + 1,
		username: currentUser.username,
		yearsExperience: yearsExperience,
		skills: skills,
		createdAt: new Date().toISOString(),
	}

	if (existingResumeIndex >= 0) {
		// Update existing resume
		resumes[existingResumeIndex] = resumeData
		showNotification("Resume updated successfully")
	} else {
		// Add new resume
		resumes.push(resumeData)
		showNotification("Resume added successfully")
	}

	saveData()
	showCandidateTab("view-resume")
}

function loadCandidateResume() {
	const resumeDisplay = document.getElementById("resume-display")
	const resume = resumes.find((r) => r.username === currentUser.username)

	if (resume) {
		let skillsHtml = ""
		resume.skills.forEach((skill) => {
			skillsHtml += `
                <div class="skill-item">
                    <span class="skill-name">${skill.name}</span>
                    <div class="skill-bar">
                        <div class="skill-level" style="width: ${
													skill.proficiency * 10
												}%"></div>
                    </div>
                    <span class="skill-rating">${skill.proficiency}/10</span>
                </div>
            `
		})

		resumeDisplay.innerHTML = `
            <div class="resume-header">
                <h3>${resume.username}</h3>
                <p><strong>Years of Experience:</strong> ${resume.yearsExperience}</p>
            </div>
            <div class="resume-skills">
                <h4>Skills</h4>
                ${skillsHtml}
            </div>
        `
	} else {
		resumeDisplay.innerHTML =
			'<p>You have not added a resume yet. Use the "Add/Update Resume" option to create one.</p>'
	}
}

function loadAllResumes() {
	const resumesList = document.getElementById("all-resumes-list")

	if (resumes.length === 0) {
		resumesList.innerHTML = "<p>No resumes available.</p>"
		return
	}

	let html = `
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Experience</th>
                    <th>Skills</th>
                </tr>
            </thead>
            <tbody>
    `

	resumes.forEach((resume) => {
		const skillsText = resume.skills.map((s) => s.name).join(", ")

		html += `
            <tr>
                <td>${resume.id}</td>
                <td>${resume.username}</td>
                <td>${resume.yearsExperience} years</td>
                <td>${skillsText}</td>
            </tr>
        `
	})

	html += `
            </tbody>
        </table>
    `

	resumesList.innerHTML = html
}

// Searching and filtering
function handleSearch(e) {
	e.preventDefault()

	const skillInputs = document.querySelectorAll(".required-skill")
	const requiredSkills = []

	skillInputs.forEach((input) => {
		if (input.value.trim() !== "") {
			requiredSkills.push(input.value.toLowerCase())
		}
	})

	if (requiredSkills.length === 0) {
		showNotification("Please enter at least one required skill", true)
		return
	}

	// Calculate match scores
	const results = resumes.map((resume) => {
		const candidateSkills = resume.skills.map((s) => s.name.toLowerCase())
		let matchCount = 0
		let totalProficiency = 0

		requiredSkills.forEach((skill) => {
			const matchIndex = candidateSkills.findIndex((s) => s.includes(skill))
			if (matchIndex >= 0) {
				matchCount++
				totalProficiency += resume.skills[matchIndex].proficiency
			}
		})

		const matchPercentage = matchCount / requiredSkills.length
		const avgProficiency =
			matchCount > 0 ? totalProficiency / matchCount / 10 : 0
		const matchScore = (matchPercentage * 0.7 + avgProficiency * 0.3) * 100

		return {
			...resume,
			matchScore: matchScore.toFixed(2),
		}
	})

	// Sort by match score (highest first)
	results.sort((a, b) => b.matchScore - a.matchScore)

	// Display results
	const resultsContainer = document.getElementById("search-results")

	if (results.length === 0) {
		resultsContainer.innerHTML = "<p>No matching candidates found.</p>"
		return
	}

	let html = `
        <h3>Search Results</h3>
        <p>Found ${results.length} candidates matching your criteria:</p>
        <table>
            <thead>
                <tr>
                    <th>Rank</th>
                    <th>Name</th>
                    <th>Experience</th>
                    <th>Match Score</th>
                    <th>Skills</th>
                </tr>
            </thead>
            <tbody>
    `

	results.forEach((result, index) => {
		if (result.matchScore > 0) {
			const skillsText = result.skills.map((s) => s.name).join(", ")

			html += `
                <tr>
                    <td>${index + 1}</td>
                    <td>${result.username}</td>
                    <td>${result.yearsExperience} years</td>
                    <td>${result.matchScore}%</td>
                    <td>${skillsText}</td>
                </tr>
            `
		}
	})

	html += `
            </tbody>
        </table>
    `

	resultsContainer.innerHTML = html
}

// Add some default data for testing
function addSampleData() {
	if (users.length === 0) {
		users = [
			{ username: "recruiter", password: "pass123", role: "recruiter" },
			{ username: "candidate1", password: "pass123", role: "candidate" },
			{ username: "candidate2", password: "pass123", role: "candidate" },
		]

		resumes = [
			{
				id: 1,
				username: "candidate1",
				yearsExperience: 3,
				skills: [
					{ name: "JavaScript", proficiency: 8 },
					{ name: "HTML", proficiency: 9 },
					{ name: "CSS", proficiency: 7 },
					{ name: "React", proficiency: 6 },
				],
				createdAt: new Date().toISOString(),
			},
			{
				id: 2,
				username: "candidate2",
				yearsExperience: 5,
				skills: [
					{ name: "Python", proficiency: 9 },
					{ name: "Machine Learning", proficiency: 7 },
					{ name: "Data Analysis", proficiency: 8 },
					{ name: "SQL", proficiency: 6 },
				],
				createdAt: new Date().toISOString(),
			},
		]

		saveData()
	}
}

// Initialize with sample data (comment this out in production)
addSampleData()
